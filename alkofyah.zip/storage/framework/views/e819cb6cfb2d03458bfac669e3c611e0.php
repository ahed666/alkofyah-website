<p><strong>Name:</strong> <?php echo e($name); ?></p>
<p><strong>Email:</strong> <?php echo e($email); ?></p>
<p><strong>Subject:</strong> <?php echo e($subject); ?></p>
<p><strong>Message:</strong></p>
<p><?php echo e($message_text); ?></p>
<?php /**PATH C:\xampp\htdocs\alkofyah\resources\views/emails/contact.blade.php ENDPATH**/ ?>