<div class="container mt-4">
<div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
                <p class="text-primary text-uppercase mb-2">// <?php echo e(__('app.sections_titles.categories_title')); ?></p>
                <h1 class="display-6 mb-4"><?php echo e(__('app.sections_titles.categories_sub_title')); ?></h1>
            </div>
    <div class="owl-carousel category-slider">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="owl-carousel-item category-item text-center">
                <a class="d-grid algin-items-center justify-content-center" href="<?php echo e(route('category.show', $category->slug)); ?>">
                    <img src="<?php echo e(Voyager::image($category->image)); ?>" 
                        class="rounded-circle img-fluid" 
                        style="width: 100px; height: 100px; object-fit: cover;">
                    <p class="mt-2"><?php echo e($category['name_' . app()->getLocale()]); ?></p>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


<?php /**PATH C:\xampp\htdocs\alkofyah\resources\views/components/categories.blade.php ENDPATH**/ ?>