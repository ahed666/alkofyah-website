

<?php $__env->startSection('title', __('app.titles.home_title')); ?>
<?php $__env->startSection('description', __('app.contents.home_content')); ?>
<?php $__env->startSection('keywords', __('app.keywords.home_keywords')); ?>
<?php $__env->startSection('content'); ?>
<!-- Carousel Start -->
   <?php if (isset($component)) { $__componentOriginal9331d2b5f0f79e45aea83246643d7a6c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9331d2b5f0f79e45aea83246643d7a6c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sliders','data' => ['sliders' => $sliders]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sliders'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['sliders' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sliders)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9331d2b5f0f79e45aea83246643d7a6c)): ?>
<?php $attributes = $__attributesOriginal9331d2b5f0f79e45aea83246643d7a6c; ?>
<?php unset($__attributesOriginal9331d2b5f0f79e45aea83246643d7a6c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9331d2b5f0f79e45aea83246643d7a6c)): ?>
<?php $component = $__componentOriginal9331d2b5f0f79e45aea83246643d7a6c; ?>
<?php unset($__componentOriginal9331d2b5f0f79e45aea83246643d7a6c); ?>
<?php endif; ?>
    <!-- Carousel End -->


    <!-- categories -->

    <?php if (isset($component)) { $__componentOriginal37388ca31ef32494cb356e39b42b6415 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal37388ca31ef32494cb356e39b42b6415 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.categories','data' => ['categories' => $categories]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('categories'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['categories' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($categories)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal37388ca31ef32494cb356e39b42b6415)): ?>
<?php $attributes = $__attributesOriginal37388ca31ef32494cb356e39b42b6415; ?>
<?php unset($__attributesOriginal37388ca31ef32494cb356e39b42b6415); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal37388ca31ef32494cb356e39b42b6415)): ?>
<?php $component = $__componentOriginal37388ca31ef32494cb356e39b42b6415; ?>
<?php unset($__componentOriginal37388ca31ef32494cb356e39b42b6415); ?>
<?php endif; ?>

    <!-- Facts Start -->
   <?php if (isset($component)) { $__componentOriginaldf63abbd7be320448a91cf8e3a73a3ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf63abbd7be320448a91cf8e3a73a3ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.facts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('facts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf63abbd7be320448a91cf8e3a73a3ee)): ?>
<?php $attributes = $__attributesOriginaldf63abbd7be320448a91cf8e3a73a3ee; ?>
<?php unset($__attributesOriginaldf63abbd7be320448a91cf8e3a73a3ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf63abbd7be320448a91cf8e3a73a3ee)): ?>
<?php $component = $__componentOriginaldf63abbd7be320448a91cf8e3a73a3ee; ?>
<?php unset($__componentOriginaldf63abbd7be320448a91cf8e3a73a3ee); ?>
<?php endif; ?>
    <!-- Facts End -->




    <?php if(count($newestProducts)>0): ?>
    <?php if (isset($component)) { $__componentOriginal7ab4e3010ccc660afdf789a022643abe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ab4e3010ccc660afdf789a022643abe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.newest-products','data' => ['products' => $newestProducts]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('newest-products'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['products' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($newestProducts)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ab4e3010ccc660afdf789a022643abe)): ?>
<?php $attributes = $__attributesOriginal7ab4e3010ccc660afdf789a022643abe; ?>
<?php unset($__attributesOriginal7ab4e3010ccc660afdf789a022643abe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ab4e3010ccc660afdf789a022643abe)): ?>
<?php $component = $__componentOriginal7ab4e3010ccc660afdf789a022643abe; ?>
<?php unset($__componentOriginal7ab4e3010ccc660afdf789a022643abe); ?>
<?php endif; ?>
    <?php endif; ?>

    <!-- Service Start -->
    <div class="container-xxl py-6">
        <div class="container">
            <div class="row g-5">
                <!-- fa-birthday-cake fa-truck -->
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                    <p class="text-primary text-uppercase mb-2">// <?php echo e(__('app.sections_titles.services_title')); ?></p>
                    <h1 class="display-6 mb-4"><?php echo e(__('app.sections_titles.services_sub_title')); ?></h1>
                    <p class="mb-5"><?php echo e($services['section_description'][app()->getLocale()]); ?></p>
                    <div class="row gy-5 gx-4">
                        <?php $__currentLoopData = $services['services']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6 wow fadeIn" data-wow-delay="0.1s">
                            <div class="d-flex align-items-center mb-3">
                                <div class="flex-shrink-0 btn-square bg-primary rounded-circle mx-3">
                                    <i class="fa <?php echo e($service['icon']); ?> text-white"></i>
                                </div>
                                <h5 class="mb-0"><?php echo e($service['title'][app()->getLocale()]); ?></h5>
                            </div>
                            <span><?php echo e($service['description'][app()->getLocale()]); ?></span>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                        
                    </div>
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="row img-twice position-relative h-100">
                        <div class="col-6">
                            <img class="img-fluid rounded" src="img/service-1.jpg" alt="Baker preparing a fresh loaf of bread at Alkofyah Bakery for quality products">
                        </div>
                        <div class="col-6 align-self-end">
                            <img class="img-fluid rounded" src="img/service-2.jpg" alt="Alkofyah Bakery delivery car bringing fresh pastries to customers' doors">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Service End -->

    <!-- offers -->
    <?php if(count($offers)>0): ?>
    <?php if (isset($component)) { $__componentOriginald8a19ed7bbed8d4d9c5949238b7ddf66 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8a19ed7bbed8d4d9c5949238b7ddf66 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.offers','data' => ['offers' => $offers]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('offers'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['offers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($offers)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8a19ed7bbed8d4d9c5949238b7ddf66)): ?>
<?php $attributes = $__attributesOriginald8a19ed7bbed8d4d9c5949238b7ddf66; ?>
<?php unset($__attributesOriginald8a19ed7bbed8d4d9c5949238b7ddf66); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8a19ed7bbed8d4d9c5949238b7ddf66)): ?>
<?php $component = $__componentOriginald8a19ed7bbed8d4d9c5949238b7ddf66; ?>
<?php unset($__componentOriginald8a19ed7bbed8d4d9c5949238b7ddf66); ?>
<?php endif; ?>
    <?php endif; ?>
    <!-- offers end -->

    <!-- branchs  -->
    <?php if(count($branches)>0): ?>
    <?php if (isset($component)) { $__componentOriginal1b008e26aa429b5e449ff40d0168ccf5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b008e26aa429b5e449ff40d0168ccf5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.branches','data' => ['branches' => $branches]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('branches'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['branches' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($branches)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b008e26aa429b5e449ff40d0168ccf5)): ?>
<?php $attributes = $__attributesOriginal1b008e26aa429b5e449ff40d0168ccf5; ?>
<?php unset($__attributesOriginal1b008e26aa429b5e449ff40d0168ccf5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b008e26aa429b5e449ff40d0168ccf5)): ?>
<?php $component = $__componentOriginal1b008e26aa429b5e449ff40d0168ccf5; ?>
<?php unset($__componentOriginal1b008e26aa429b5e449ff40d0168ccf5); ?>
<?php endif; ?>
    <?php endif; ?>
    <!-- branchs end -->




    <!-- Testimonial Start -->
    <!-- <div class="container-xxl bg-light my-6 py-6 pb-0">
        <div class="container">
            <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
                <p class="text-primary text-uppercase mb-2">// Client's Review</p>
                <h1 class="display-6 mb-4">More Than 20000+ Customers Trusted Us</h1>
            </div>
            <div class="owl-carousel testimonial-carousel wow fadeInUp" data-wow-delay="0.1s">
                <div class="testimonial-item bg-white rounded p-4">
                    <div class="d-flex align-items-center mb-4">
                        <img class="flex-shrink-0 rounded-circle border p-1" src="img/testimonial-1.jpg" alt="">
                        <div class="ms-4">
                            <h5 class="mb-1">Client Name</h5>
                            <span>Profession</span>
                        </div>
                    </div>
                    <p class="mb-0">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
                </div>
                <div class="testimonial-item bg-white rounded p-4">
                    <div class="d-flex align-items-center mb-4">
                        <img class="flex-shrink-0 rounded-circle border p-1" src="img/testimonial-2.jpg" alt="">
                        <div class="ms-4">
                            <h5 class="mb-1">Client Name</h5>
                            <span>Profession</span>
                        </div>
                    </div>
                    <p class="mb-0">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
                </div>
                <div class="testimonial-item bg-white rounded p-4">
                    <div class="d-flex align-items-center mb-4">
                        <img class="flex-shrink-0 rounded-circle border p-1" src="img/testimonial-3.jpg" alt="">
                        <div class="ms-4">
                            <h5 class="mb-1">Client Name</h5>
                            <span>Profession</span>
                        </div>
                    </div>
                    <p class="mb-0">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
                </div>
                <div class="testimonial-item bg-white rounded p-4">
                    <div class="d-flex align-items-center mb-4">
                        <img class="flex-shrink-0 rounded-circle border p-1" src="img/testimonial-4.jpg" alt="">
                        <div class="ms-4">
                            <h5 class="mb-1">Client Name</h5>
                            <span>Profession</span>
                        </div>
                    </div>
                    <p class="mb-0">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
                </div>
            </div>
            <div class="bg-primary text-light rounded-top p-5 my-6 mb-0 wow fadeInUp" data-wow-delay="0.1s">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <h1 class="display-4 text-light mb-0">Subscribe Our Newsletter</h1>
                    </div>
                    <div class="col-md-6 text-md-end">
                        <div class="position-relative">
                            <input class="form-control bg-transparent border-light w-100 py-3 ps-4 pe-5" type="text" placeholder="Your email">
                            <button type="button" class="btn btn-dark py-2 px-3 position-absolute top-0 end-0 mt-2 mx-2">SignUp</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <!-- Testimonial End -->

   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alkofyah\resources\views/home.blade.php ENDPATH**/ ?>