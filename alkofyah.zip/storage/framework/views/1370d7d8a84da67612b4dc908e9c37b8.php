


<?php $__env->startSection('title', __('app.titles.product_title', ['product' => $product->{'name_' . app()->getLocale()}, 'category' => $product->category->{'name_' . app()->getLocale()}])); ?>
<?php $__env->startSection('description', __('app.contents.product_content', ['product' => $product->{'name_' . app()->getLocale()}, 'category' => $product->category->{'name_' . app()->getLocale()}])); ?>
<?php $__env->startSection('keywords', __('app.keywords.product_keywords', ['product' => $product->{'name_' . app()->getLocale()}, 'category' => $product->category->{'name_' . app()->getLocale()}])); ?>


<?php $__env->startSection('content'); ?>

<div class="container-fluid page-header py-6 wow fadeIn" data-wow-delay="0.1s">
        <div class="container text-center pt-5 pb-3">
            <h1 class="display-4 text-white animated slideInDown mb-3"><?php echo e($product['name_' . app()->getLocale()]); ?></h1>
            <nav aria-label="breadcrumb animated slideInDown">
                <ol class="breadcrumb justify-content-center mb-0">
                    <li class="breadcrumb-item"><a class="text-white" href="<?php echo e(route('home')); ?>"><?php echo e(__('app.navbar.home')); ?></a></li>
                    <li class="breadcrumb-item   "> <a class="text-white" href="<?php echo e(route('category.show',$product->category->slug)); ?>" ><?php echo e($product->category['name_' . app()->getLocale()]); ?></a></li>
                     <li class="breadcrumb-item text-primary active" aria-current="page"><?php echo e($product['name_' . app()->getLocale()]); ?></li>

                </ol>
            </nav>
        </div>
</div>
<div class="container mt-4">
    <div class="row">
      
        <div class="col-md-6">
            <div id="productCarousel" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <?php
                        $images = json_decode($product->images); 
                    ?>
                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="carousel-item <?php echo e($index == 0 ? 'active' : ''); ?>">
                            <img src="<?php echo e(Voyager::image($image)); ?>" class="d-block w-100 rounded" alt="<?php echo e($product['name_'.app()->getLocale()]); ?>-<?php echo e($product['name_' . app()->getLocale()]); ?>">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#productCarousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#productCarousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                </button>
            </div>
        </div>

       
        <div class="col-md-6">
            <h2 class="fw-bold"><?php echo e($product['name_' . app()->getLocale()]); ?></h2>

            
            <div class="mb-3">
                <?php if($product->new): ?>
                    <span class="badge bg-success mx-2">New</span>
                <?php endif; ?>
                <?php if($product->featured): ?>
                    <span class="badge bg-warning text-dark">Featured</span>
                <?php endif; ?>
            </div>

            <p class="text-muted"><?php echo e($product['desc_' . app()->getLocale()]); ?></p>

            <h4 class="text-primary">
            <?php echo e(number_format($product->price, 2)); ?> <?php echo e(__('app.labels.aed')); ?> <?php echo e(__('/')); ?> 
            <?php echo e($product->unit_count); ?><?php echo e(__(' ')); ?> <?php echo e(__('app.labels.'.$product->unit_text)); ?>

            
        </h4>

           
        </div>
    </div>

   
    <h3 class="mt-5">Related Products</h3>
    <div class="row">
        <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodRelated): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.product-card','data' => ['product' => $prodRelated]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($prodRelated)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $attributes = $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $component = $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alkofyah\resources\views/product.blade.php ENDPATH**/ ?>