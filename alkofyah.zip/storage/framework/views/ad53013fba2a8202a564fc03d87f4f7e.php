
<?php $__env->startSection('title', __('app.titles.contact_title')); ?>
<?php $__env->startSection('description', __('app.contents.contact_content')); ?>
<?php $__env->startSection('keywords', __('app.keywords.contact_keywords')); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Header Start -->
<div class="container-fluid page-header py-6 wow fadeIn" data-wow-delay="0.1s">
    <div class="container text-center pt-5 pb-3">
        <h1 class="display-4 text-white animated slideInDown mb-3"><?php echo e(__('app.navbar.contact')); ?></h1>
        <nav aria-label="breadcrumb animated slideInDown">
            <ol class="breadcrumb justify-content-center mb-0">
                <li class="breadcrumb-item"><a class="text-white" href="<?php echo e(route('home')); ?>"><?php echo e(__('app.navbar.home')); ?></a>
                </li>
                <li class="breadcrumb-item text-primary active" aria-current="page"><?php echo e(__('app.navbar.contact')); ?></li>
            </ol>
        </nav>
    </div>
</div>
<!-- Page Header End -->


<!-- Contact Start -->
<div class="container-xxl py-6 contact-section">
    <div class="container">
        <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
            <p class="text-primary text-uppercase mb-2">// <?php echo e(__('app.sections_titles.contact_title')); ?></p>
            <h1 class="display-6 mb-4"><?php echo e(__('app.sections_titles.contact_sub_title')); ?></h1>
        </div>
        <div class="row g-4 ">
            <!-- Left Side: Contact Information -->
            <div class="col-lg-5 contact-info wow fadeInUp" data-wow-delay="0.1s">
                <div class=" p-4 rounded">
                    <h3 class="mb-4"><?php echo e(__('app.labels.our_branches')); ?></h3>
                    <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mb-3">
                        <h5 class="text-primary"><?php echo e($branch['name_'.app()->getLocale()]); ?></h5>
                        <p><i class="fas fa-map-marker-alt text-primary"></i>
                            <?php echo e($branch['location_'.app()->getLocale()]); ?></p>
                        <p><i class="fas fa-phone text-primary"></i> <?php echo e($branch->phone); ?></p>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <hr>

                    <h4 class="mb-3"><?php echo e(__('app.labels.contact_info')); ?></h4>
                    <p><i class="fas fa-envelope text-primary"></i> <?php echo e($contact_info['email']); ?></p>

                    <div class="mt-3">
                        <h4 class="mb-3"><?php echo e(__('app.labels.follow_us')); ?></h4>
                        <div class="d-flex justif-content-between ">
                            <a class="btn btn-square btn-outline-light text-primary  border-primary rounded-circle me-1"
                                href=""><i class="fab fa-instagram"></i></a>
                            <a class="btn btn-square btn-outline-light text-primary  border-primary rounded-circle me-1"
                                href=""><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-square btn-outline-light text-primary  border-primary rounded-circle me-1"
                                target="_blank" href="https://wa.me/<?php echo e($contact_info['whatsapp']); ?>"><i
                                    class="fab fa-whatsapp"></i></a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Side: Contact Form -->
            <div class="col-lg-7 wow fadeInUp" data-wow-delay="0.2s">
                <div class=" p-4 rounded">
                    <form action="<?php echo e(route('contact.submit')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                        <?php endif; ?>

                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="text" class="form-control" name="name" id="name"
                                        placeholder="Your Name" required>
                                    <label for="name"><?php echo e(__('app.labels.name')); ?></label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="email" class="form-control" name="email" id="email"
                                        placeholder="Your Email" required>
                                    <label for="email"><?php echo e(__('app.labels.email')); ?></label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-floating">
                                    <input type="text" class="form-control" name="subject" id="subject"
                                        placeholder="Subject" required>
                                    <label for="subject"><?php echo e(__('app.labels.subject')); ?></label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-floating">
                                    <textarea class="form-control" name="message" placeholder="Leave a message here"
                                        id="message" style="height: 200px" required></textarea>
                                    <label for="message"><?php echo e(__('app.labels.message')); ?></label>
                                </div>
                            </div>
                            <div class="col-12 text-center">
                                <button class="btn btn-primary rounded-pill py-3 px-5"
                                    type="submit"><?php echo e(__('app.buttons.sendmessage')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- Contact End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\alkofyah\resources\views/contact.blade.php ENDPATH**/ ?>