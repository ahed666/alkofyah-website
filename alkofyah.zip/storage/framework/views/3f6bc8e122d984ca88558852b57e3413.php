<div class="container mt-4">
    <h2 class="text-center mb-4">Our Branches</h2>
    
    <div class="row">
        <!-- Left Half: Branch Cards -->
        <div class="col-md-6">
            <div class="row">
                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12 mb-3">
                    <div class="card shadow-sm">
                        <div class="row g-0">
                            <div class="col-md-4">
                                <img src="<?php echo e(Voyager::image($branch->image)); ?>" class="img-fluid rounded-start" alt="<?php echo e($branch->name); ?>">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($branch['name_'.app()->getLocale()]); ?></h5>
                                    <p class="card-text"><i class="fa fa-map-marker-alt text-danger"></i> <?php echo e($branch->location); ?></p>
                                    <p class="card-text"><i class="fa fa-phone text-primary"></i> <?php echo e($branch->phone); ?></p>
                                    <button class="btn btn-sm btn-outline-primary" onclick="focusOnBranch(<?php echo e($branch->latitude); ?>, <?php echo e($branch->longitude); ?>)">
                                        View on Map
                                    </button>
                                    <a href="https://www.google.com/maps/dir/?api=1&destination=<?php echo e($branch->latitude); ?>,<?php echo e($branch->longitude); ?>" target="_blank"
                                     class="btn btn-sm btn-outline-primary">
                                        Get Directions
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <!-- Right Half: Google Map -->
        <div class="col-md-6">
            <div id="map" style="height: 400px; width: 100%;"></div>
        </div>
    </div>
</div>
  <script>
    
  </script>
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css"/>
  <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
  <script>
                var branches = <?php echo json_encode($branches, 15, 512) ?>; // Get branches from database

   
    var map = L.map('map').setView([25.276987, 55.296249], 10); // Default: Dubai

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    
    branches.forEach(branch => {
        L.marker([branch.latitude, branch.longitude])
            .addTo(map)
            .bindPopup(`<b>${branch.name_en}</b>`)
            .openPopup();
    });
    function focusOnBranch(lat, lng) {
        map.setView([parseFloat(lat), parseFloat(lng)], 14);  // Set the map center and zoom level
    }
</script><?php /**PATH C:\xampp\htdocs\alkofyah\resources\views/components/branchs.blade.php ENDPATH**/ ?>