<div class="col-lg-3 col-md-6  wow fadeInUp" data-wow-delay="<?php echo e(($delay ?? '0.1').'s'); ?>">
                    <div class="product-item d-flex flex-column bg-white rounded overflow-hidden h-100">
                        <div class="text-center p-4">
                            <div class="d-inline-block border border-primary rounded-pill px-3 mb-3">
                                 <?php echo e(number_format($product->price, 2)); ?> <?php echo e(__('app.labels.aed')); ?> <?php echo e(__('/')); ?> <?php echo e($product->unit_count); ?><?php echo e(__(' ')); ?> <?php echo e(__('app.labels.'.$product->unit_text)); ?></div>
                            <h3 class="mb-3"><?php echo e($product['name_'.app()->getLocale()]); ?></h3>
                            <span><?php echo e($product['desc_'.app()->getLocale()]); ?></span>
                        </div>
                        <div class="position-relative mt-auto product-img">
                        <?php
                            $images = json_decode($product->images);
                        ?>
                            <img class="img-fluid " src="<?php echo e(Voyager::image($images[0])); ?>" alt="<?php echo e($product['alt_'.app()->getLocale()]); ?>">
                            <?php if($product->new): ?>
                            <div class="position-absolute custom-bottom px-1">
                                <span class="bg-success text-white px-2 py-1 rounded fw-bold"><?php echo e(__('app.labels.new')); ?></span>
                            </div>
                            <?php endif; ?>
                            <div class="product-overlay">
                                <a class="btn btn-lg-square btn-outline-light rounded-circle" href="<?php echo e(route('product.show',$product->slug)); ?>"><i class="fa fa-eye text-primary"></i></a>
                            </div>
                        </div>
                    </div>
</div><?php /**PATH C:\xampp\htdocs\alkofyah\resources\views/components/product-card.blade.php ENDPATH**/ ?>