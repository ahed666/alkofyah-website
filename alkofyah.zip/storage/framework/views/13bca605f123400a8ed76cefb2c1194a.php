<div class="container-xxl  my-6 py-6 pt-0">
    <div class="container">    
    <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
                <p class="text-primary text-uppercase mb-2">// 🔥 <?php echo e(__('app.sections_titles.offers_title')); ?> 🔥</p>
                <h1 class="display-6 mb-4"> <?php echo e(__('app.sections_titles.offers_sub_title')); ?></h1>
    </div>
   
    <div class="row">
        <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="card shadow-sm">
                <?php if($offer->image): ?>
                    <img src="<?php echo e(Voyager::image($offer->image)); ?>" class="card-img-top" alt="<?php echo e($offer->title_en); ?>">
                <?php endif; ?>
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($offer['title_'.app()->getLocale()]); ?></h5>
                    <p class="card-text"><?php echo e($offer['desc_'.app()->getLocale()]); ?></p>
                    <span class="badge bg-danger">-<?php echo e($offer->discount); ?>% Off</span>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
</div>
<?php /**PATH C:\xampp\htdocs\alkofyah\resources\views/components/offers.blade.php ENDPATH**/ ?>